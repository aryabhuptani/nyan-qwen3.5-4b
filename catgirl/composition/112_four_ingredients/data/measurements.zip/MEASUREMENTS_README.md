# CPU reproduction of study112

Do not extract over the live repository or an existing result directory. From the repository study112 directory, choose a NEW separate directory (the mkdir command must succeed):

    mkdir ../study112-reproduction
    python3 -m zipfile -e data/measurements.zip ../study112-reproduction
    cd ../study112-reproduction

Using a Python interpreter with NumPy installed, run:

    python3 analyze.py --manifest analysis_inputs.reproduction.json --output analysis_reproduced

Use a new output directory. No model download, GPU or inference is required. All five primary label versions are included. Each archive entry's original and published SHA256 appears in MEASUREMENTS_MANIFEST.json; only phase-metadata host paths may differ. All scientific raw data are byte-identical to the executed experiment. The archive includes discovery calibration and dose-choice inputs, control measurements, all primary analysis inputs, and the float32 precision sensitivity data. Compare analysis CSVs with the published analysis; summary input-path hashes can differ because the extraction directory differs. Persistence is a separate extension and is not included here.
